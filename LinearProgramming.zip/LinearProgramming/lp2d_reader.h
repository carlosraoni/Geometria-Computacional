#ifndef LP2D_READER_H
#define LP2D_READER_H

#include "linear_program2d.h"

namespace lp2D{

LinearProgram2D * readLinearProgram2D(const char * file);

}

#endif // LP2D_READER_H
